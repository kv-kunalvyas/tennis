#ifndef MAIN_H
#define MAIN_H

//Called during calibration
//When clicking on the image: new colors are tracked
void mouseHandler(int event, int x, int y, int flags, void *param);

#endif
